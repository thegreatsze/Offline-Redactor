"""
Core redaction engine using Microsoft Presidio.

Detects and anonymizes PII entities in text, returning both the redacted
text and a structured list of detected entities with positions.

Optional BERT/transformer-based NER can be layered on top of Presidio results
when the `transformers` package is available. Install with:
    pip install transformers torch
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Optional

from presidio_analyzer import AnalyzerEngine, RecognizerResult
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig

from custom_recognizers import register_custom_recognizers

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_ENTITIES = [
    # Built-in Presidio / spaCy
    "PERSON",
    "PHONE_NUMBER",
    "EMAIL_ADDRESS",
    "CREDIT_CARD",
    "US_SSN",
    "LOCATION",
    "ORGANIZATION",
    "DATE_TIME",
    "IP_ADDRESS",
    # Custom
    "CONTRACT_ID",
    "EIN",
    "BANK_ROUTING",
    "NRIC_SG",
    "ADDRESS",
]

# BERT entity groups → Presidio entity type mapping
_BERT_ENTITY_MAP = {
    "PER": "PERSON",
    "ORG": "ORGANIZATION",
    "LOC": "LOCATION",
    "MISC": "MISC",
}


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class DetectedEntity:
    """Represents a single PII entity found in the text."""

    entity_type: str
    original_value: str
    start: int
    end: int
    score: float
    source: str = "presidio"  # "presidio" | "bert" | "manual"


@dataclass
class RedactionResult:
    """Result returned by the redaction engine."""

    redacted_text: str
    entities: List[DetectedEntity] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Optional BERT NER
# ---------------------------------------------------------------------------


class _BertNER:
    """
    Thin wrapper around HuggingFace transformers pipeline for NER.

    Falls back gracefully if `transformers` or `torch` is not installed.
    """

    def __init__(self, model_name: str = "dslim/bert-base-NER"):
        self.model_name = model_name
        self._pipeline = None
        self.available = False
        self._load()

    def _load(self) -> None:
        try:
            from transformers import pipeline as hf_pipeline
            self._pipeline = hf_pipeline(
                "ner",
                model=self.model_name,
                aggregation_strategy="simple",
            )
            self.available = True
        except Exception:
            self.available = False

    def analyze(self, text: str, score_threshold: float = 0.7) -> List[DetectedEntity]:
        """
        Run transformer NER on text and return DetectedEntity objects.

        Args:
            text: Input text.
            score_threshold: Minimum confidence to include an entity.

        Returns:
            List of DetectedEntity objects (source="bert").
        """
        if not self.available or self._pipeline is None:
            return []

        try:
            results = self._pipeline(text)
        except Exception:
            return []

        entities: List[DetectedEntity] = []
        for r in results:
            score = float(r.get("score", 0.0))
            if score < score_threshold:
                continue
            entity_type = _BERT_ENTITY_MAP.get(r.get("entity_group", ""), r.get("entity_group", "MISC"))
            word = r.get("word", text[r["start"]: r["end"]])
            # Strip leading ## subword tokens
            word = re.sub(r"^#+", "", word).strip()
            if not word:
                continue
            start, end = r["start"], r["end"]
            if not ContractRedactor._is_valid_entity(text, start, end):
                continue
            entities.append(
                DetectedEntity(
                    entity_type=entity_type,
                    original_value=word,
                    start=r["start"],
                    end=r["end"],
                    score=round(score, 4),
                    source="bert",
                )
            )
        return entities


# Singleton so model loads once per process
_bert_ner_instance: Optional[_BertNER] = None


def get_bert_ner(model_name: str = "dslim/bert-base-NER") -> _BertNER:
    """Return (or lazily create) the shared BertNER instance.

    Retries loading if a previous attempt failed (e.g. torch was installed
    after the process started).
    """
    global _bert_ner_instance
    if (
        _bert_ner_instance is None
        or _bert_ner_instance.model_name != model_name
        or not _bert_ner_instance.available
    ):
        _bert_ner_instance = _BertNER(model_name)
    return _bert_ner_instance


# ---------------------------------------------------------------------------
# Main redactor
# ---------------------------------------------------------------------------


class ContractRedactor:
    """
    Redaction engine combining Presidio NER and optional BERT NER.

    Args:
        confidence_threshold: Minimum score (0–1) for an entity to be redacted.
        entities: List of entity type strings to detect. Defaults to DEFAULT_ENTITIES.
        use_bert: Whether to also run BERT-based NER on top of Presidio.
    """

    def __init__(
        self,
        confidence_threshold: float = 0.7,
        entities: Optional[List[str]] = None,
        use_bert: bool = False,
    ) -> None:
        self.confidence_threshold = confidence_threshold
        self.entities = entities or DEFAULT_ENTITIES
        self.use_bert = use_bert

        self._analyzer = AnalyzerEngine()
        register_custom_recognizers(self._analyzer)
        self._anonymizer = AnonymizerEngine()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def redact(self, text: str, manual_phrases: Optional[List[str]] = None) -> RedactionResult:
        """
        Analyze text for PII and return the redacted version plus entity details.

        Args:
            text: Raw contract text to process.
            manual_phrases: Additional phrases to redact regardless of score.

        Returns:
            A RedactionResult with redacted text and entity list.

        Raises:
            ValueError: If text is empty or None.
        """
        if not text or not text.strip():
            raise ValueError("Input text is empty.")

        # --- Presidio analysis ---
        requested_entities = self.entities if self.entities else DEFAULT_ENTITIES
        analyzer_results: List[RecognizerResult] = self._analyzer.analyze(
            text=text,
            entities=requested_entities,
            language="en",
            score_threshold=self.confidence_threshold,
        )

        # --- BERT NER (optional) ---
        bert_entities: List[DetectedEntity] = []
        if self.use_bert:
            bert = get_bert_ner()
            bert_entities = bert.analyze(text, score_threshold=self.confidence_threshold)

        # --- Manual phrases ---
        manual_entities: List[DetectedEntity] = []
        if manual_phrases:
            manual_entities = self._find_manual_phrases(text, manual_phrases)

        # --- Build combined entity list ---
        presidio_entities = self._build_entity_list(text, analyzer_results)
        all_entities = self._merge_entities(presidio_entities, bert_entities, manual_entities)

        # --- Anonymize via Presidio (using its analyzer results) ---
        operators = {
            et: OperatorConfig("replace", {"new_value": f"[REDACTED_{et}]"})
            for et in requested_entities
        }
        anonymized = self._anonymizer.anonymize(
            text=text,
            analyzer_results=analyzer_results,
            operators=operators,
        )

        # Apply BERT + manual redactions on top via simple string replacement
        redacted_text = anonymized.text
        for entity in sorted(bert_entities + manual_entities, key=lambda e: -len(e.original_value)):
            label = f"[REDACTED_{entity.entity_type}]"
            redacted_text = redacted_text.replace(entity.original_value, label)

        return RedactionResult(redacted_text=redacted_text, entities=all_entities)

    def analyze_only(self, text: str, manual_phrases: Optional[List[str]] = None) -> List[DetectedEntity]:
        """
        Run detection without producing redacted output (for the review phase).

        Args:
            text: Raw text to analyze.
            manual_phrases: Additional phrases to include.

        Returns:
            Sorted list of DetectedEntity objects.
        """
        if not text or not text.strip():
            return []

        requested_entities = self.entities if self.entities else DEFAULT_ENTITIES
        analyzer_results = self._analyzer.analyze(
            text=text,
            entities=requested_entities,
            language="en",
            score_threshold=self.confidence_threshold,
        )
        presidio_entities = self._build_entity_list(text, analyzer_results)

        bert_entities: List[DetectedEntity] = []
        if self.use_bert:
            bert = get_bert_ner()
            bert_entities = bert.analyze(text, score_threshold=self.confidence_threshold)

        manual_entities: List[DetectedEntity] = []
        if manual_phrases:
            manual_entities = self._find_manual_phrases(text, manual_phrases)

        return self._merge_entities(presidio_entities, bert_entities, manual_entities)

    def redact_from_entities(self, text: str, entities: List[DetectedEntity]) -> str:
        """
        Apply redaction to text given a pre-approved list of entities.

        Useful for the two-phase workflow where the user has reviewed and
        selected which entities to redact.

        Args:
            text: Original text.
            entities: Approved entities (only these will be redacted).

        Returns:
            Redacted text string.
        """
        # Sort by position descending so replacements don't shift indices
        sorted_entities = sorted(entities, key=lambda e: e.start, reverse=True)
        chars = list(text)
        for entity in sorted_entities:
            label = list(f"[REDACTED_{entity.entity_type}]")
            chars[entity.start: entity.end] = label
        return "".join(chars)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_valid_entity(text: str, start: int, end: int) -> bool:
        """
        Return True only when the span represents a genuine, standalone PII token.

        Filters applied (any failure → discard):

        1. **Multi-line span** – if the matched value contains a newline it is
           almost certainly a PDF-extraction layout artefact (e.g. a name run
           into the next line's label).  Rejected unconditionally.

        2. **Too short** – alphabetic-only values of 2 or fewer characters
           (e.g. "MM", "ED", "NY") are initials, abbreviations, or word
           fragments and are rejected regardless of case.  Values of exactly 3
           all-lowercase alphabetic characters (e.g. "the", "and") are also
           rejected.

        3. **Hyphenated line-continuation** – PDF text extraction sometimes
           splits a hyphenated word across lines: "UNAUTHORIS-\\nED".  When
           the character immediately before the span (possibly after a newline)
           is a hyphen, the span is a continuation of the previous word and is
           rejected.

        4. **Immediate word-boundary check** – the character directly before
           ``start`` and directly after ``end`` must not be an alphanumeric /
           underscore character.
        """
        value = text[start:end]

        # ── filter 1: multi-line artefact ──────────────────────────────────
        if "\n" in value:
            return False

        # ── filter 2: too short ────────────────────────────────────────────
        if len(value) <= 2 and value.isalpha():
            return False
        if len(value) == 3 and value.isalpha() and value.islower():
            return False

        # ── filter 3: hyphenated line-continuation ─────────────────────────
        # Look backward past any whitespace/newlines to find a hyphen
        look = start - 1
        while look >= 0 and text[look] in (" ", "\t", "\n", "\r"):
            look -= 1
        if look >= 0 and text[look] == "-":
            return False

        # ── filter 4: immediate word-boundary check ────────────────────────
        if start > 0 and re.match(r"\w", text[start - 1]):
            return False
        if end < len(text) and re.match(r"\w", text[end]):
            return False

        return True

    def _build_entity_list(
        self,
        original_text: str,
        results: List[RecognizerResult],
    ) -> List[DetectedEntity]:
        """Convert raw Presidio results into DetectedEntity objects.

        Sub-word matches (e.g. "ed" from "obtained") are discarded via
        extended boundary and minimum-length validation.
        """
        entities: List[DetectedEntity] = []
        for result in results:
            if not self._is_valid_entity(original_text, result.start, result.end):
                continue
            original_value = original_text[result.start: result.end]
            entities.append(
                DetectedEntity(
                    entity_type=result.entity_type,
                    original_value=original_value,
                    start=result.start,
                    end=result.end,
                    score=round(result.score, 4),
                    source="presidio",
                )
            )
        return entities

    def _find_manual_phrases(self, text: str, phrases: List[str]) -> List[DetectedEntity]:
        """
        Locate manually specified phrases in the text.

        Matching rules:
          - Whole-word / whole-phrase only: matches must sit at word boundaries
            so that "ed" does not match inside "redacted", and "an" does not
            match inside "contract".
          - Case-sensitive: the phrase is matched exactly as typed.  This
            prevents a casually typed lowercase word (e.g. "the") from
            redacting every article in the document.  If the user wants
            case-insensitive matching they should type the phrase in the
            case it appears in the document.
        """
        entities: List[DetectedEntity] = []
        for phrase in phrases:
            phrase = phrase.strip()
            if not phrase:
                continue
            # \b anchors work on the transition between \w and \W characters.
            # For phrases that start/end with non-word chars we fall back to
            # a lookahead/lookbehind so the boundary is still respected.
            left  = r"\b" if re.match(r"\w", phrase[0])  else r"(?<!\w)"
            right = r"\b" if re.match(r"\w", phrase[-1]) else r"(?!\w)"
            pattern = re.compile(left + re.escape(phrase) + right)
            for match in pattern.finditer(text):
                entities.append(
                    DetectedEntity(
                        entity_type="MANUAL",
                        original_value=match.group(),
                        start=match.start(),
                        end=match.end(),
                        score=1.0,
                        source="manual",
                    )
                )
        return entities

    def _merge_entities(self, *entity_lists: List[DetectedEntity]) -> List[DetectedEntity]:
        """
        Merge entity lists, removing overlapping duplicates.

        Keeps the entity with the highest score when positions overlap.
        """
        all_entities: List[DetectedEntity] = []
        for lst in entity_lists:
            all_entities.extend(lst)

        # Sort by start position, then by score descending
        all_entities.sort(key=lambda e: (e.start, -e.score))

        merged: List[DetectedEntity] = []
        last_end = -1
        for entity in all_entities:
            if entity.start >= last_end:
                merged.append(entity)
                last_end = entity.end
            # else: overlapping — skip (lower-score duplicate)

        return sorted(merged, key=lambda e: e.start)
