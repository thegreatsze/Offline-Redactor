"""
Tests for the core redaction engine and custom recognizers.

Run with: python -m pytest tests/ -v
"""

import sys
import os

# Ensure the project root is on the path so imports resolve correctly
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from redactor import ContractRedactor, DEFAULT_ENTITIES


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def sample_contract_text():
    """Load the synthetic sample contract."""
    sample_path = os.path.join(os.path.dirname(__file__), "sample_contract.txt")
    with open(sample_path, "r", encoding="utf-8") as f:
        return f.read()


@pytest.fixture(scope="module")
def redactor():
    """Create a ContractRedactor with default settings (threshold=0.7)."""
    return ContractRedactor(confidence_threshold=0.7)


@pytest.fixture(scope="module")
def result(redactor, sample_contract_text):
    """Run redaction once and reuse the result across tests."""
    return redactor.redact(sample_contract_text)


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def entity_types_found(result):
    return {e.entity_type for e in result.entities}


# ---------------------------------------------------------------------------
# Basic detection tests
# ---------------------------------------------------------------------------


class TestEntityDetection:
    def test_person_detected(self, result):
        """At least one PERSON entity should be found."""
        assert "PERSON" in entity_types_found(result), (
            "Expected PERSON entities — check spaCy model is loaded."
        )

    def test_email_detected(self, result):
        """Email addresses must be detected."""
        assert "EMAIL_ADDRESS" in entity_types_found(result)

    def test_phone_detected(self, result):
        """Phone numbers must be detected."""
        assert "PHONE_NUMBER" in entity_types_found(result)

    def test_ssn_detected(self, result):
        """US SSN must be detected."""
        assert "US_SSN" in entity_types_found(result)

    def test_date_detected(self, result):
        """DATE_TIME entities should be detected."""
        assert "DATE_TIME" in entity_types_found(result)

    def test_ip_detected(self, result):
        """IP address should be detected."""
        assert "IP_ADDRESS" in entity_types_found(result)

    def test_credit_card_detected(self, result):
        """Credit card number must be detected."""
        assert "CREDIT_CARD" in entity_types_found(result)


# ---------------------------------------------------------------------------
# Custom recognizer tests
# ---------------------------------------------------------------------------


class TestCustomRecognizers:
    def test_contract_id_long_format(self, redactor):
        """CONTRACT-YYYY-NNNNN format should be detected as CONTRACT_ID."""
        text = "Reference: CONTRACT-2024-00187 for this engagement."
        r = redactor.redact(text)
        assert any(e.entity_type == "CONTRACT_ID" for e in r.entities), (
            "CONTRACT-YYYY-NNNNN pattern not detected"
        )

    def test_contract_id_short_format(self, redactor):
        """CON-NNNNN format should be detected as CONTRACT_ID."""
        text = "Secondary reference CON-00442 applies."
        r = redactor.redact(text)
        assert any(e.entity_type == "CONTRACT_ID" for e in r.entities), (
            "CON-NNNNN pattern not detected"
        )

    def test_ein_detected(self, redactor):
        """NN-NNNNNNN format should be detected as EIN."""
        text = "Employer Identification Number: 47-2931856"
        r = redactor.redact(text)
        assert any(e.entity_type == "EIN" for e in r.entities), (
            "EIN pattern not detected"
        )

    def test_routing_number_with_context(self, redactor):
        """9-digit routing number with context keyword should be detected."""
        text = "Bank routing number: 021000021 for wire transfers."
        r = redactor.redact(text)
        assert any(e.entity_type == "BANK_ROUTING" for e in r.entities), (
            "BANK_ROUTING not detected even with context"
        )

    def test_contract_id_in_full_contract(self, result):
        """Full sample contract should yield at least one CONTRACT_ID."""
        assert any(e.entity_type == "CONTRACT_ID" for e in result.entities)

    def test_ein_in_full_contract(self, result):
        """Full sample contract should yield at least one EIN."""
        assert any(e.entity_type == "EIN" for e in result.entities)


# ---------------------------------------------------------------------------
# Confidence threshold tests
# ---------------------------------------------------------------------------


class TestConfidenceThreshold:
    def test_high_threshold_reduces_entities(self, sample_contract_text):
        """Higher threshold should produce fewer or equal entities than lower."""
        low = ContractRedactor(confidence_threshold=0.3)
        high = ContractRedactor(confidence_threshold=0.95)
        low_result = low.redact(sample_contract_text)
        high_result = high.redact(sample_contract_text)
        assert len(high_result.entities) <= len(low_result.entities)

    def test_all_entities_above_threshold(self, sample_contract_text):
        """Every returned entity must meet the configured threshold."""
        threshold = 0.7
        r = ContractRedactor(confidence_threshold=threshold).redact(sample_contract_text)
        for entity in r.entities:
            assert entity.score >= threshold, (
                f"Entity {entity.entity_type} has score {entity.score} < {threshold}"
            )

    def test_zero_threshold_returns_entities(self, sample_contract_text):
        """A threshold of 0.0 should detect at least as many entities as 0.7."""
        r_zero = ContractRedactor(confidence_threshold=0.0).redact(sample_contract_text)
        r_default = ContractRedactor(confidence_threshold=0.7).redact(sample_contract_text)
        assert len(r_zero.entities) >= len(r_default.entities)


# ---------------------------------------------------------------------------
# Output cleanliness tests
# ---------------------------------------------------------------------------


class TestRedactedOutput:
    def test_raw_ssn_not_in_output(self, result):
        """The raw SSN from the sample contract must not appear in the redacted text."""
        assert "372-84-9210" not in result.redacted_text

    def test_raw_email_not_in_output(self, result):
        """Raw email addresses must not appear in the redacted text."""
        assert "margaret.holloway@nexcorp.com" not in result.redacted_text

    def test_raw_credit_card_not_in_output(self, result):
        """Raw credit card number must not appear in the redacted text."""
        assert "4111 1111 1111 1111" not in result.redacted_text

    def test_redacted_markers_present(self, result):
        """Redacted text should contain [REDACTED_...] markers."""
        assert "[REDACTED_" in result.redacted_text

    def test_redacted_text_is_string(self, result):
        assert isinstance(result.redacted_text, str)
        assert len(result.redacted_text) > 0

    def test_entity_list_is_list(self, result):
        assert isinstance(result.entities, list)

    def test_entity_fields_populated(self, result):
        """All entity objects must have required fields with valid values."""
        for entity in result.entities:
            assert entity.entity_type, "entity_type must not be empty"
            assert entity.original_value, "original_value must not be empty"
            assert entity.start >= 0
            assert entity.end > entity.start
            assert 0.0 <= entity.score <= 1.0


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_empty_text_raises(self, redactor):
        with pytest.raises(ValueError, match="empty"):
            redactor.redact("")

    def test_whitespace_only_raises(self, redactor):
        with pytest.raises(ValueError, match="empty"):
            redactor.redact("   \n\t  ")

    def test_no_pii_text(self, redactor):
        """Text with no PII should return unchanged text and empty entity list."""
        text = "This agreement covers general consulting services and deliverables."
        r = redactor.redact(text)
        assert isinstance(r.redacted_text, str)
        # Entities may be empty or very few; redacted text should not have markers
        # that don't correspond to actual PII (soft assertion)
        assert r.entities == [] or all(
            e.score >= 0.7 for e in r.entities
        )

    def test_entity_type_filter(self, sample_contract_text):
        """Requesting only EMAIL_ADDRESS should not return PERSON entities."""
        r = ContractRedactor(
            confidence_threshold=0.5, entities=["EMAIL_ADDRESS"]
        ).redact(sample_contract_text)
        for entity in r.entities:
            assert entity.entity_type == "EMAIL_ADDRESS"
