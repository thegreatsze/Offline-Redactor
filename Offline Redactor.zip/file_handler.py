"""
File handler for reading, rendering, and writing redacted PDF, DOCX, and TXT files.

PDF redaction is performed using PyMuPDF's native redaction annotations,
producing black boxes over PII in the original PDF layout.

DOCX redaction replaces matching text runs with [REDACTED_TYPE] labels.
"""

from __future__ import annotations

import io
import os
import re
from pathlib import Path
from typing import List, Optional


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------


def read_file(filepath: str) -> str:
    """
    Read text content from a file, auto-detecting the file type.

    Args:
        filepath: Absolute or relative path to the file.

    Returns:
        Extracted text as a single string.

    Raises:
        ValueError: If the file type is unsupported or the file is empty.
        FileNotFoundError: If the file does not exist.
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {filepath}")

    suffix = path.suffix.lower()

    if suffix == ".txt":
        text = _read_txt(path)
    elif suffix == ".docx":
        text = _read_docx(path)
    elif suffix == ".pdf":
        text = _read_pdf(path)
    else:
        raise ValueError(
            f"Unsupported file type '{suffix}'. Supported types: .txt, .docx, .pdf"
        )

    if not text or not text.strip():
        raise ValueError(f"File is empty or contains no extractable text: {filepath}")

    return text


def _read_txt(path: Path) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def _read_docx(path: Path) -> str:
    from docx import Document
    doc = Document(str(path))
    parts = []
    for para in doc.paragraphs:
        parts.append(para.text)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    parts.append(para.text)
    return "\n".join(parts)


def _read_pdf(path: Path) -> str:
    import fitz
    pages = []
    with fitz.open(str(path)) as doc:
        for page in doc:
            pages.append(page.get_text())
    return "\n".join(pages)


# ---------------------------------------------------------------------------
# PDF rendering (for in-window display)
# ---------------------------------------------------------------------------


def render_pdf_pages(filepath: str, zoom: float = 1.5) -> List[bytes]:
    """
    Render each PDF page as a PNG image.

    Args:
        filepath: Path to the PDF file.
        zoom: Render scale factor (higher = better quality, larger file).

    Returns:
        List of PNG byte strings, one per page.
    """
    import fitz
    images = []
    with fitz.open(filepath) as doc:
        mat = fitz.Matrix(zoom, zoom)
        for page in doc:
            pix = page.get_pixmap(matrix=mat, alpha=False)
            images.append(pix.tobytes("png"))
    return images


def render_pdf_pages_with_highlights(
    filepath: str,
    entity_values: List[str],
    zoom: float = 1.5,
    color: tuple = (1.0, 0.9, 0.0),
) -> List[bytes]:
    """
    Render PDF pages with PII entities highlighted.

    Uses temporary highlight annotations — does NOT modify the source file.

    Args:
        filepath: Path to the PDF file.
        entity_values: List of text strings to highlight.
        zoom: Render scale factor.
        color: RGB tuple for the highlight colour (default: yellow).

    Returns:
        List of PNG byte strings, one per page.
    """
    import fitz
    images = []
    with fitz.open(filepath) as doc:
        for page in doc:
            for value in entity_values:
                if not isinstance(value, str) or not value.strip():
                    continue
                rects = page.search_for(value)
                for rect in rects:
                    annot = page.add_highlight_annot(rect)
                    annot.set_colors(stroke=color)
                    annot.update()
            mat = fitz.Matrix(zoom, zoom)
            pix = page.get_pixmap(matrix=mat, alpha=False)
            images.append(pix.tobytes("png"))
    return images


# ---------------------------------------------------------------------------
# DOCX rendering (for in-window display via HTML)
# ---------------------------------------------------------------------------


def render_docx_as_html(filepath: str) -> str:
    """
    Convert a DOCX file to HTML for in-window display using mammoth.

    Args:
        filepath: Path to the DOCX file.

    Returns:
        HTML string representing the document content.
    """
    try:
        import mammoth
    except ImportError as e:
        raise ImportError("mammoth is required for DOCX display. pip install mammoth") from e

    with open(filepath, "rb") as f:
        result = mammoth.convert_to_html(f)
    return result.value


def render_docx_as_html_with_highlights(filepath: str, entity_value_colors: List[tuple]) -> str:
    """
    Convert a DOCX to HTML and wrap entity values in colour-coded <mark> spans.

    Args:
        filepath: Path to the DOCX file.
        entity_value_colors: List of (text, css_color_string) pairs, e.g.
            [("John Smith", "#FFD700"), ("NICA REALTY", "#FF6B6B")]

    Returns:
        HTML string with highlighted PII spans.
    """
    import html as html_module

    html_content = render_docx_as_html(filepath)

    # Sort by length descending to avoid inner-match collisions
    for value, color in sorted(entity_value_colors, key=lambda x: len(x[0]), reverse=True):
        if not value.strip():
            continue
        escaped_value = html_module.escape(value)
        html_content = re.sub(
            re.escape(escaped_value),
            f'<mark style="background:{color};padding:1px 2px;border-radius:2px">{escaped_value}</mark>',
            html_content,
            flags=re.IGNORECASE,
        )
    return html_content


# ---------------------------------------------------------------------------
# PDF redaction
# ---------------------------------------------------------------------------


def apply_pdf_redactions(
    filepath: str,
    entity_values: List[str],
    output_path: str,
    fill_color: tuple = (0.0, 0.0, 0.0),
) -> None:
    """
    Apply black-box redactions to a PDF file using PyMuPDF.

    Each occurrence of an entity value is covered with a filled rectangle.
    The resulting PDF contains no recoverable text in redacted areas.

    Args:
        filepath: Path to the source PDF.
        entity_values: List of text strings to redact.
        output_path: Destination path for the redacted PDF.
        fill_color: RGB tuple for the redaction fill (default: black).
    """
    import fitz

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

    with fitz.open(filepath) as doc:
        for page in doc:
            for value in entity_values:
                if not value.strip():
                    continue
                rects = page.search_for(value)
                for rect in rects:
                    page.add_redact_annot(rect, fill=fill_color)
            page.apply_redactions()
        doc.save(output_path)


def build_redacted_pdf_bytes(
    filepath: str,
    entity_values: List[str],
    coord_redactions: Optional[dict] = None,
) -> bytes:
    """
    Produce a redacted PDF in memory and return its bytes for download.

    Args:
        filepath: Path to the source PDF.
        entity_values: List of text strings to redact via search.
        coord_redactions: Optional dict mapping page index (0-based) to a list of
            (x0, y0, x1, y1) tuples in PDF point coordinates.  These are applied
            as additional black-box redactions (e.g. from the drawing tool).

    Returns:
        Bytes of the redacted PDF.
    """
    import fitz

    with fitz.open(filepath) as doc:
        for page in doc:
            for value in entity_values:
                if not value.strip():
                    continue
                rects = page.search_for(value)
                for rect in rects:
                    page.add_redact_annot(rect, fill=(0.0, 0.0, 0.0))
            if coord_redactions and page.number in coord_redactions:
                for (x0, y0, x1, y1) in coord_redactions[page.number]:
                    page.add_redact_annot(fitz.Rect(x0, y0, x1, y1), fill=(0.0, 0.0, 0.0))
            page.apply_redactions()
        return doc.tobytes()


# ---------------------------------------------------------------------------
# DOCX redaction
# ---------------------------------------------------------------------------


def apply_docx_redactions(
    filepath: str,
    entities: List,  # List[DetectedEntity]
    output_path: str,
) -> None:
    """
    Apply text redactions to a DOCX file and save the result.

    Replaces entity text in paragraph runs with [REDACTED_TYPE] labels.
    Formatting in affected paragraphs may be simplified.

    Args:
        filepath: Path to the source DOCX.
        entities: List of DetectedEntity objects to redact.
        output_path: Destination path for the redacted DOCX.
    """
    from docx import Document

    replacements = _build_replacement_map(entities)

    doc = Document(filepath)
    for para in doc.paragraphs:
        _redact_paragraph(para, replacements)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    _redact_paragraph(para, replacements)

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    doc.save(output_path)


def build_redacted_docx_bytes(filepath: str, entities: List) -> bytes:
    """
    Produce a redacted DOCX in memory and return its bytes for download.

    Args:
        filepath: Path to the source DOCX.
        entities: List of DetectedEntity objects to redact.

    Returns:
        Bytes of the redacted DOCX.
    """
    from docx import Document

    replacements = _build_replacement_map(entities)

    doc = Document(filepath)
    for para in doc.paragraphs:
        _redact_paragraph(para, replacements)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    _redact_paragraph(para, replacements)

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# TXT redaction
# ---------------------------------------------------------------------------


def write_redacted_txt(redacted_text: str, output_path: str) -> None:
    """
    Write redacted text to a plain-text file.

    Args:
        redacted_text: The redacted text content.
        output_path: Destination path for the output .txt file.
    """
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(redacted_text)


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _build_replacement_map(entities: List) -> List[tuple]:
    """
    Build a sorted list of (original_value, replacement_label) pairs.

    Sorted longest-first to avoid partial replacements (e.g. 'John' before 'John Smith').
    """
    seen = set()
    pairs = []
    for e in entities:
        val = e.original_value
        if val and val not in seen:
            seen.add(val)
            pairs.append((val, f"[REDACTED_{e.entity_type}]"))
    pairs.sort(key=lambda p: len(p[0]), reverse=True)
    return pairs


def _redact_paragraph(para, replacements: List[tuple]) -> None:
    """
    Replace entity text within a DOCX paragraph.

    Joins all runs into full paragraph text, applies replacements, then
    writes back into the first run (clearing others).  This preserves
    paragraph-level formatting (alignment, spacing) while accepting that
    per-run character formatting in affected paragraphs is simplified.

    Args:
        para: python-docx Paragraph object.
        replacements: List of (original, replacement) string pairs.
    """
    full_text = para.text
    modified = full_text
    for original, replacement in replacements:
        modified = modified.replace(original, replacement)

    if modified == full_text or not para.runs:
        return

    # Copy formatting from the first run as the baseline
    first_run = para.runs[0]
    first_run.text = modified
    for run in para.runs[1:]:
        run.text = ""
