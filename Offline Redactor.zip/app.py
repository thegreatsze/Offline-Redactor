"""
OFFLINE REDACTOR — Contract Document Redaction Tool
Powered by Microsoft Presidio + spaCy. Fully local, no data leaves your machine.

Run with:
    streamlit run app.py
"""

from __future__ import annotations

import base64
import io as _io
import json
import os
import re
import tempfile
from pathlib import Path
from typing import List

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

from file_handler import (
    read_file,
    render_pdf_pages,
    render_pdf_pages_with_highlights,
    render_docx_as_html,
    render_docx_as_html_with_highlights,
    build_redacted_pdf_bytes,
    build_redacted_docx_bytes,
)
from redactor import ContractRedactor, DEFAULT_ENTITIES, get_bert_ner

# ─────────────────────────────────────────────────────────────────────────────
# Drawing component (bidirectional via Streamlit component protocol)
# ─────────────────────────────────────────────────────────────────────────────
_COMPONENT_DIR = Path(__file__).parent / "drawing_component"
_drawing_canvas = components.declare_component("drawing_canvas", path=str(_COMPONENT_DIR))


def drawing_canvas(image_b64: str, rects: list, key: str):
    """Wrap the custom drawing component."""
    return _drawing_canvas(image_b64=image_b64, rects=rects, key=key, default=None)


_ENTITY_LIST_DIR = Path(__file__).parent / "entity_list_component"
_entity_list_component = components.declare_component(
    "entity_list", path=str(_ENTITY_LIST_DIR)
)


def entity_list_widget(entities_data: list, approved: list, key: str):
    """Compact entity list component. Returns {approved: [...], removed: [...]}."""
    return _entity_list_component(
        entities=entities_data, approved=approved, key=key, default=None
    )


# ─────────────────────────────────────────────────────────────────────────────
# Page config
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Offline Redactor",
    page_icon="🔒",
    layout="wide",
    initial_sidebar_state="expanded",
)

DRAW_ZOOM = 1.5

SOURCE_COLOURS = {
    "presidio": ("#FFE000", "Yellow — auto-detected"),
    "bert":     ("#FF8C00", "Orange — BERT model"),
    "manual":   ("#FF6B6B", "Red — manual"),
}
DEFAULT_CSS_COLOR = "#FFE000"


def _source_css(source: str) -> str:
    return SOURCE_COLOURS.get(source, (DEFAULT_CSS_COLOR,))[0]


# ─────────────────────────────────────────────────────────────────────────────
# CSS
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
:root {
    --bg:      #f5f0e8;
    --bg-card: #fffdf7;
    --bg-side: #ede8dc;
    --border:  #d6cebc;
    --brn-dk:  #3a2e1e;
    --brn-md:  #5a3e28;
    --brn-lt:  #8b6040;
}

.stApp { background: var(--bg); }

/* hide sidebar collapse arrow */
[data-testid="stSidebarCollapseButton"],
[data-testid="collapsedControl"],
button[kind="header"] { display: none !important; }

[data-testid="stSidebar"] {
    background: linear-gradient(180deg,#ede8dc,#e6e0d3);
    border-right: 1px solid var(--border);
    min-width: 270px;
}
[data-testid="stSidebar"] h3 {
    font-size: 0.86rem; font-weight: 700; color: var(--brn-dk);
    text-transform: uppercase; letter-spacing: 0.08em;
    margin: 1rem 0 0.25rem;
    padding-bottom: 3px; border-bottom: 1px solid var(--border);
}
[data-testid="stSidebar"] .stMarkdown p { font-size: 0.82rem; color: #555; }

.priv-banner {
    background: linear-gradient(135deg,#fdf0dc,#f5e4c0);
    border: 1px solid #e8c97a; border-left: 4px solid #c8922a;
    border-radius: 8px; padding: 10px 16px;
    font-size: 0.84rem; color: #5a3a0a; margin-bottom: 16px;
}

/* ── Doc panels ──────────────────────────────────────────────────────────── */

/* PDF single-page viewer — no scroll, image fills the column */
.doc-panel-pdf {
    border: 1px solid var(--border); border-radius: 8px;
    box-shadow: 0 2px 12px rgba(90,62,40,0.06);
    overflow: hidden;
    background: #fff;
}
.doc-panel-pdf img {
    width: 100%;
    display: block;
}

/* Scrollable panel for DOCX / TXT */
.doc-panel {
    background: var(--bg-card);
    border: 1px solid var(--border); border-radius: 8px;
    box-shadow: 0 2px 12px rgba(90,62,40,0.06);
    padding: 16px 20px;
    height: calc(100vh - 230px);
    min-height: 600px;
    overflow-y: auto;
    font-family: Georgia,serif; font-size: 13px; line-height: 1.8;
}

/* ── Entity list component iframe ────────────────────────────────────────── */
/* Remove the iframe border/shadow Streamlit adds around custom components */
iframe[title="entity_list"] {
    border: 1px solid var(--border) !important;
    border-radius: 6px !important;
}

/* Page nav bar */
.page-nav {
    display: flex; align-items: center; justify-content: center;
    gap: 10px; padding: 4px 0 6px;
    font-size: 0.84rem; color: var(--brn-md); font-weight: 600;
}

/* ── Suppress Streamlit's loading fade ───────────────────────────────────── */
/* Prevents the whole app from dimming on every rerun */
[data-stale="true"] { opacity: 1 !important; transition: none !important; }
.stApp > div { transition: none !important; }

.right-panel-header {
    font-size: 0.86rem; font-weight: 700; color: var(--brn-dk);
    text-transform: uppercase; letter-spacing: 0.08em;
    border-bottom: 2px solid var(--brn-md);
    padding-bottom: 4px; margin-bottom: 8px;
}

.legend-swatch {
    display: inline-block; width: 11px; height: 11px;
    border-radius: 2px; margin-right: 3px; vertical-align: middle;
}

.entity-pill {
    display: flex; align-items: baseline; gap: 5px;
    padding: 3px 6px; border-radius: 5px;
    border: 1px solid var(--border); background: var(--bg);
    font-size: 0.77rem; line-height: 1.35;
    transition: background 0.12s;
}
.entity-pill:hover { background: #e8dfd0; }
.entity-pill.dimmed { opacity: 0.25; }
.type-badge {
    background: var(--brn-md); color: #fff;
    font-size: 0.63rem; padding: 1px 4px;
    border-radius: 3px; white-space: nowrap; flex-shrink: 0;
}
.entity-value { flex:1; word-break:break-word; color: var(--brn-dk); }
.entity-conf  { color:#999; font-size:0.70rem; flex-shrink:0; }

mark { padding:1px 3px; border-radius:3px; font-weight:600; }

/* file uploader */
[data-testid="stFileUploader"] { width:72%; margin:0 auto; }
[data-testid="stFileUploaderDropzone"] {
    min-height:200px !important;
    display:flex; flex-direction:column;
    align-items:center; justify-content:center;
    border:2px dashed var(--brn-lt) !important;
    border-radius:14px !important;
    background:linear-gradient(135deg,#f0ebe0,#ede5d8) !important;
    font-size:1rem; color:var(--brn-md) !important;
    transition:background 0.2s;
}
[data-testid="stFileUploaderDropzone"]:hover {
    background:linear-gradient(135deg,#e8dfd0,#e2d8c8) !important;
}

details [data-testid="stCheckbox"] label p { font-size:0.76rem !important; }

/* primary buttons */
button[data-testid="baseButton-primary"] {
    background:linear-gradient(135deg,#5a3e28,#7a5c40) !important;
    color:white !important; border:none !important;
    border-radius:6px !important; font-weight:600 !important;
    box-shadow:0 2px 8px rgba(90,62,40,0.25) !important;
}
button[data-testid="baseButton-primary"]:hover {
    background:linear-gradient(135deg,#7a5c40,#9a7c60) !important;
}

/* secondary/default buttons */
button[data-testid="baseButton-secondary"] {
    background:#f0ebe0 !important; color:var(--brn-dk) !important;
    border:1px solid var(--border) !important; border-radius:6px !important;
}
button[data-testid="baseButton-secondary"]:hover { background:#e2d8c8 !important; }
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# Session state
# ─────────────────────────────────────────────────────────────────────────────
defaults: dict = {
    "phase": "upload",
    "original_text": "",
    "detected_entities": [],
    "approved_indices": set(),
    "manual_phrases": [],
    "tmp_path": None,
    "file_name": None,
    "file_suffix": None,
    "redacted_bytes": None,
    "redacted_mime": None,
    "redacted_ext": None,
    "drawing_mode": False,
    "preview_page": 0,       # current page shown in both normal and drawing views
    "drawn_rects": {},        # {page_idx: [{left,top,width,height}, ...]}
    "redacted_tmp_path": None,  # temp file of redacted PDF (for done-phase drawing)
}
for k, v in defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v

# ─────────────────────────────────────────────────────────────────────────────
# Utility functions
# ─────────────────────────────────────────────────────────────────────────────

def _sync_checkboxes() -> None:
    approved = set()
    for i in range(len(st.session_state.detected_entities)):
        if st.session_state.get(f"chk_{i}", i in st.session_state.approved_indices):
            approved.add(i)
    st.session_state.approved_indices = approved


def _set_all(value: bool) -> None:
    n = len(st.session_state.detected_entities)
    for i in range(n):
        st.session_state[f"chk_{i}"] = value
    st.session_state.approved_indices = set(range(n)) if value else set()


def _approved_vc() -> List[tuple]:
    return [(str(st.session_state.detected_entities[i].original_value),
             _source_css(st.session_state.detected_entities[i].source))
            for i in st.session_state.approved_indices]


def _approved_vals() -> List[str]:
    return [str(st.session_state.detected_entities[i].original_value)
            for i in st.session_state.approved_indices]


def _pages_to_html(pages_bytes: List[bytes]) -> str:
    """Convert list of PNG byte strings to an HTML block of <img> tags."""
    parts = []
    for pb in pages_bytes:
        b64 = base64.b64encode(pb).decode()
        parts.append(f'<img src="data:image/png;base64,{b64}">')
    return "".join(parts)


@st.cache_data(show_spinner=False)
def _cached_pdf_highlights(filepath: str, vals_key: tuple, zoom: float) -> List[bytes]:
    """Cache rendered PDF pages with highlights. vals_key is a sorted tuple for hashing."""
    return render_pdf_pages_with_highlights(filepath, list(vals_key), zoom=zoom)


@st.cache_data(show_spinner=False)
def _cached_pdf_pages(filepath: str, zoom: float) -> List[bytes]:
    """Cache rendered plain PDF pages."""
    return render_pdf_pages(filepath, zoom=zoom)


def _highlight_text(text: str, vc: List[tuple]) -> str:
    import html as _h
    s = _h.escape(text).replace("\n", "<br>")
    for val, color in sorted(vc, key=lambda x: len(x[0]), reverse=True):
        if not str(val).strip():
            continue
        ev = _h.escape(str(val))
        s = re.sub(re.escape(ev),
                   f'<mark style="background:{color}">{ev}</mark>',
                   s, flags=re.IGNORECASE)
    return s


def _highlight_markers(text: str) -> str:
    import html as _h
    s = _h.escape(text).replace("\n", "<br>")
    return re.sub(r"(\[REDACTED_[A-Z_]+\])",
                  r'<mark style="background:#FFE000">\1</mark>', s)


def _apply_redactions() -> None:
    approved = [st.session_state.detected_entities[i]
                for i in st.session_state.approved_indices]
    suffix = st.session_state.file_suffix
    tmp    = st.session_state.tmp_path

    with st.spinner("Processing…"):
        if suffix == ".pdf":
            coord_reds: dict = {}
            for pidx, rects in st.session_state.drawn_rects.items():
                coord_reds[pidx] = [
                    (r["left"] / DRAW_ZOOM, r["top"] / DRAW_ZOOM,
                     (r["left"] + r["width"])  / DRAW_ZOOM,
                     (r["top"]  + r["height"]) / DRAW_ZOOM)
                    for r in rects
                ]
            data = build_redacted_pdf_bytes(
                tmp, [e.original_value for e in approved],
                coord_redactions=coord_reds or None,
            )
            # Save redacted PDF to a temp file so drawing mode can use it as background
            old = st.session_state.get("redacted_tmp_path")
            if old and os.path.exists(old):
                try: os.unlink(old)
                except OSError: pass
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tf:
                tf.write(data)
                st.session_state.redacted_tmp_path = tf.name
            mime, ext = "application/pdf", ".pdf"
        elif suffix == ".docx":
            data = build_redacted_docx_bytes(tmp, approved)
            mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            ext  = ".docx"
        else:
            engine = ContractRedactor(confidence_threshold=0.0,
                                      entities=list({e.entity_type for e in approved}))
            data = engine.redact_from_entities(
                st.session_state.original_text, approved).encode("utf-8")
            mime, ext = "text/plain", ".txt"

    st.session_state.update(redacted_bytes=data, redacted_mime=mime,
                            redacted_ext=ext, phase="done",
                            drawing_mode=False)
    st.rerun(scope="app")


def _page_nav(page_idx: int, n_pages: int, key_prefix: str) -> None:
    """Render prev/next page navigation buttons (shared by preview and drawing)."""
    nc1, nc2, nc3 = st.columns([1, 4, 1])
    if nc1.button("◀", key=f"{key_prefix}_prev", disabled=(page_idx == 0)):
        st.session_state.preview_page -= 1
        st.rerun()
    nc2.markdown(
        f"<div class='page-nav'>Page {page_idx + 1} of {n_pages}</div>",
        unsafe_allow_html=True,
    )
    if nc3.button("▶", key=f"{key_prefix}_next", disabled=(page_idx >= n_pages - 1)):
        st.session_state.preview_page += 1
        st.rerun()


def _n_pdf_pages(filepath: str) -> int:
    import fitz
    with fitz.open(filepath) as doc:
        return len(doc)


def _render_doc_preview(suffix: str, tmp_path: str) -> None:
    """Show document preview with highlights.
    PDFs: one page at a time (no scroll), prev/next nav.
    DOCX/TXT: full scrollable panel.
    """
    vc   = _approved_vc()
    vals = _approved_vals()

    if suffix == ".pdf":
        n_pages  = _n_pdf_pages(tmp_path)
        page_idx = min(st.session_state.preview_page, n_pages - 1)
        st.session_state.preview_page = page_idx

        _page_nav(page_idx, n_pages, "prev")

        vals_key = tuple(sorted(set(vals)))
        pages    = _cached_pdf_highlights(tmp_path, vals_key, DRAW_ZOOM)
        b64      = base64.b64encode(pages[page_idx]).decode()
        st.markdown(
            f'<div class="doc-panel-pdf">'
            f'<img src="data:image/png;base64,{b64}">'
            f'</div>',
            unsafe_allow_html=True,
        )

    elif suffix == ".docx":
        html = render_docx_as_html_with_highlights(tmp_path, vc)
        st.markdown(f'<div class="doc-panel">{html}</div>', unsafe_allow_html=True)
    else:
        hl = _highlight_text(st.session_state.original_text, vc)
        st.markdown(f'<div class="doc-panel">{hl}</div>', unsafe_allow_html=True)


def _render_doc_drawing(tmp_path: str, highlight_vals: List[str] | None = None) -> None:
    """Drawing mode: one PDF page at a time on an interactive canvas.

    Args:
        tmp_path: Path to the PDF to render as background.
        highlight_vals: Text values to highlight (yellow) on the background.
                        Pass an empty list to skip highlights (e.g. in done phase).
    """
    n_pages  = _n_pdf_pages(tmp_path)
    page_idx = min(st.session_state.preview_page, n_pages - 1)
    st.session_state.preview_page = page_idx

    _page_nav(page_idx, n_pages, "draw")

    if highlight_vals is None:
        highlight_vals = _approved_vals()

    vals_key    = tuple(sorted(set(highlight_vals)))
    pages_bytes = _cached_pdf_highlights(tmp_path, vals_key, DRAW_ZOOM)
    img_b64     = base64.b64encode(pages_bytes[page_idx]).decode()

    existing_rects = st.session_state.drawn_rects.get(page_idx, [])

    result = drawing_canvas(
        image_b64=img_b64,
        rects=existing_rects,
        key=f"canvas_p{page_idx}",
    )

    # Persist returned rects
    if result is not None:
        if result:
            st.session_state.drawn_rects[page_idx] = result
        elif page_idx in st.session_state.drawn_rects:
            del st.session_state.drawn_rects[page_idx]

    total = sum(len(v) for v in st.session_state.drawn_rects.values())
    if total:
        st.caption(
            f"**{total}** drawn box{'es' if total != 1 else ''} across all pages — "
            f"click **Apply Redactions** to embed them."
        )


def _render_redacted_doc(suffix: str, redacted_bytes: bytes) -> None:
    if suffix == ".pdf":
        # Use the saved temp file path so caching works across reruns
        rpath = st.session_state.get("redacted_tmp_path")
        if rpath and os.path.exists(rpath):
            n_pages    = _n_pdf_pages(rpath)
            pages_bytes = _cached_pdf_pages(rpath, DRAW_ZOOM)
        else:
            import fitz
            pages_bytes = []
            with fitz.open(stream=redacted_bytes, filetype="pdf") as doc:
                n_pages = len(doc)
                for page in doc:
                    pix = page.get_pixmap(
                        matrix=fitz.Matrix(DRAW_ZOOM, DRAW_ZOOM), alpha=False)
                    pages_bytes.append(pix.tobytes("png"))

        page_idx = min(st.session_state.preview_page, n_pages - 1)
        st.session_state.preview_page = page_idx
        _page_nav(page_idx, n_pages, "done")

        b64 = base64.b64encode(pages_bytes[page_idx]).decode()
        st.markdown(
            f'<div class="doc-panel-pdf">'
            f'<img src="data:image/png;base64,{b64}">'
            f'</div>',
            unsafe_allow_html=True,
        )
    elif suffix == ".docx":
        with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as tf:
            tf.write(redacted_bytes); tf_path = tf.name
        try:
            html = render_docx_as_html(tf_path)
        finally:
            os.unlink(tf_path)
        st.markdown(f'<div class="doc-panel">{html}</div>', unsafe_allow_html=True)
    else:
        text = redacted_bytes.decode("utf-8")
        st.markdown(f'<div class="doc-panel">{_highlight_markers(text)}</div>',
                    unsafe_allow_html=True)


def _scroll_sync_js(total_len: int) -> None:
    if total_len == 0:
        return
    components.html(f"""<script>
(function(){{
  function setup(){{
    try{{
      var p=window.parent.document, panel=p.querySelector('.doc-panel');
      if(!panel){{setTimeout(setup,400);return;}}
      panel.addEventListener('scroll',tick,{{passive:true}});
      tick();
      function tick(){{
        var sh=panel.scrollHeight,ch=panel.clientHeight;
        if(sh<=ch)return;
        var tf=panel.scrollTop/sh, bf=(panel.scrollTop+ch)/sh;
        p.querySelectorAll('.entity-pill[data-sf]').forEach(function(el){{
          var sf=+el.dataset.sf,ef=+el.dataset.ef;
          el.classList.toggle('dimmed',!(sf<=bf+0.06&&ef>=tf-0.06));
        }});
      }}
    }}catch(e){{}}
  }}
  setup();
}})();
</script>""", height=0, scrolling=False)


def _reset() -> None:
    for key in ("tmp_path", "redacted_tmp_path"):
        p = st.session_state.get(key)
        if p and os.path.exists(p):
            try: os.unlink(p)
            except OSError: pass
    for i in range(len(st.session_state.get("detected_entities", []))):
        st.session_state.pop(f"chk_{i}", None)
    _cached_pdf_highlights.clear()
    _cached_pdf_pages.clear()
    for k, v in defaults.items():
        st.session_state[k] = v
    st.rerun(scope="app")


# ─────────────────────────────────────────────────────────────────────────────
# Right panel (fragment — checkbox changes rerun only this fragment, not the
# full page, so the document column does NOT re-render on every tick)
# ─────────────────────────────────────────────────────────────────────────────
@st.fragment
def _render_right_panel() -> None:
    # ── Drawing mode toggle ──────────────────────────────────────────────────
    st.markdown('<div class="right-panel-header">✏️ Drawing Mode</div>',
                unsafe_allow_html=True)
    suffix = st.session_state.file_suffix

    drawing_mode = st.toggle(
        "Enable drawing mode",
        value=st.session_state.drawing_mode,
        key="draw_toggle",
        help="Drag to draw black redaction boxes on the PDF (useful for images, signatures, etc.)",
    )
    if drawing_mode != st.session_state.drawing_mode:
        st.session_state.drawing_mode = drawing_mode
        st.rerun(scope="app")

    if drawing_mode and suffix != ".pdf":
        st.info("Drawing mode is for PDF files only.")

    st.markdown("<hr style='margin:5px 0'>", unsafe_allow_html=True)

    # ── Proposed Redactions ──────────────────────────────────────────────────
    st.markdown('<div class="right-panel-header">🔍 Proposed Redactions</div>',
                unsafe_allow_html=True)

    legend = " &nbsp;".join(
        f'<span class="legend-swatch" style="background:{css}"></span>'
        f'<span style="font-size:0.72rem">{lbl}</span>'
        for css, lbl in SOURCE_COLOURS.values()
    )
    st.markdown(f'<div style="line-height:2;margin-bottom:4px">{legend}</div>',
                unsafe_allow_html=True)

    entities = st.session_state.detected_entities

    if not entities:
        st.info("No entities detected.")
        if st.button("✅ Apply Redactions", use_container_width=True,
                     type="primary", key="apply_empty"):
            _apply_redactions()
        return

    if st.button("✅ Apply Redactions", use_container_width=True,
                 type="primary", key="apply_top"):
        _apply_redactions()

    st.markdown("<hr style='margin:4px 0'>", unsafe_allow_html=True)

    # ── Entity list component ────────────────────────────────────────────────
    # Serialize entities for the HTML component
    entities_data = [
        {
            "entity_type":   e.entity_type,
            "original_value": str(e.original_value),
            "score":          round(e.score, 4),
            "color":          _source_css(e.source),
        }
        for e in entities
    ]
    approved_list = sorted(st.session_state.approved_indices)

    # Estimate height: ~26px per row + 32px header, cap at 480px
    frame_h = min(32 + 26 * len(entities), 480)

    result = entity_list_widget(
        entities_data=entities_data,
        approved=approved_list,
        key="entity_list",
    )

    # Sync state back from component interactions
    if result is not None:
        new_approved = set(result.get("approved", approved_list))
        new_removed  = set(result.get("removed", []))
        # Apply removals: drop removed entities from the master list
        if new_removed:
            keep = [i for i in range(len(entities)) if i not in new_removed]
            st.session_state.detected_entities = [entities[i] for i in keep]
            # Remap approved indices after removal
            remap = {old: new for new, old in enumerate(keep)}
            st.session_state.approved_indices = {
                remap[i] for i in new_approved if i in remap
            }
            # Clear old chk_ keys
            for i in range(len(entities)):
                st.session_state.pop(f"chk_{i}", None)
        else:
            st.session_state.approved_indices = new_approved

    st.markdown("<hr style='margin:6px 0'>", unsafe_allow_html=True)
    if st.button("✅ Apply Redactions", use_container_width=True,
                 type="primary", key="apply_bottom"):
        _apply_redactions()


# ─────────────────────────────────────────────────────────────────────────────
# Left sidebar
# ─────────────────────────────────────────────────────────────────────────────
with st.sidebar:

    st.markdown("### 📊 Confidence Threshold")
    st.caption(
        "Entities with a score below this value are ignored. "
        "Lower = more detections but more false positives."
    )
    confidence_threshold: float = st.slider(
        "Threshold", 0.0, 1.0, 0.7, 0.05, label_visibility="collapsed"
    )
    st.caption(f"Current: **{confidence_threshold:.0%}**")

    st.markdown("---")

    st.markdown("### ✏️ Manual Redaction Search")
    st.caption("Add words or phrases — matched exactly as typed, whole words only.")
    new_phrase = st.text_input("Phrase", key="phrase_input", placeholder="e.g. NICA REALTY",
                               label_visibility="collapsed")
    if st.button("Add phrase") and new_phrase.strip():
        if new_phrase.strip() not in st.session_state.manual_phrases:
            st.session_state.manual_phrases.append(new_phrase.strip())
            st.rerun()
    if st.session_state.manual_phrases:
        to_remove = None
        for i, phrase in enumerate(st.session_state.manual_phrases):
            c1, c2 = st.columns([5, 1])
            c1.markdown(f"`{phrase}`")
            if c2.button("✕", key=f"rmp_{i}"):
                to_remove = i
        if to_remove is not None:
            st.session_state.manual_phrases.pop(to_remove);  st.rerun()

    st.markdown("---")

    st.markdown("### 🤖 BERT / Transformer NER *(optional)*")
    bert_ner = get_bert_ner()
    use_bert = st.toggle(
        "Enable BERT NER", value=False, disabled=not bert_ner.available,
    )
    if not bert_ner.available:
        st.caption("Not available — install with:\n`pip install transformers torch`")
    else:
        st.caption(
            "Enabling BERT helps catch person names, organisation names, and locations "
            "phrased in uncommon ways or without surrounding context clues.\n\n"
            "⚠️ **First-time use:** triggers a one-time ~400 MB model download, "
            "cached locally for future sessions."
        )

    st.markdown("---")

    with st.expander("🏷️ Entity Types to Detect", expanded=False):
        st.caption("Uncheck categories not needed before uploading.")
        entity_checks: dict[str, bool] = {}
        for ent in DEFAULT_ENTITIES:
            entity_checks[ent] = st.checkbox(ent, value=True, key=f"ent_{ent}")

selected_entities: List[str] = [e for e, v in entity_checks.items() if v]

# ─────────────────────────────────────────────────────────────────────────────
# Title + privacy banner
# ─────────────────────────────────────────────────────────────────────────────
# ── Banner GIF (encode once, embed as data URI) ───────────────────────────────
_banner_path = Path(__file__).parent / "assets" / "banner.gif"
if _banner_path.exists():
    import base64 as _b64
    _banner_b64 = _b64.b64encode(_banner_path.read_bytes()).decode()
    _banner_src = f"data:image/gif;base64,{_banner_b64}"
else:
    _banner_src = ""

if _banner_src:
    st.markdown(
        f"""
        <div style="
            border-bottom:2px solid #d6cebc;
            margin-bottom:14px;
            padding-bottom:4px;
            display:flex;align-items:center;gap:14px;">
          <img src="{_banner_src}"
               style="height:100px;border-radius:10px;
                      box-shadow:0 4px 18px rgba(90,62,40,0.30);">
          <div style="margin-left:auto;text-align:right;
                      font-size:0.68rem;color:#bbb;line-height:1.6;">
            Powered by<br>
            <span style="color:#7a5c40;font-weight:700">
              Microsoft Presidio + spaCy</span>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
else:
    st.markdown("""
    <div style="
        display:flex;align-items:center;gap:18px;
        padding:14px 4px 12px;
        border-bottom:2px solid #d6cebc;margin-bottom:18px;">
      <div style="
        font-family:'Georgia',serif;font-size:1.9rem;font-weight:900;
        letter-spacing:0.10em;color:#2c1f0f;">OFFLINE REDACTOR</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("""
<div class="priv-banner">
🛡️ <strong>Your privacy is protected.</strong>
All analysis and redaction happens <em>entirely on your computer</em>.
No document content, text, or personal data is ever sent to the internet.
This tool works fully offline using locally installed AI models.
</div>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# Phase: Upload
# ─────────────────────────────────────────────────────────────────────────────
if st.session_state.phase == "upload":
    st.markdown(
        "<div style='text-align:center;margin:2rem 0 0.6rem;"
        "font-size:1.05rem;color:#5a3e28;font-weight:700;"
        "letter-spacing:0.04em'>Upload a contract document to begin</div>",
        unsafe_allow_html=True,
    )
    uploaded = st.file_uploader(
        "Drag and drop or click to browse — PDF, DOCX, or TXT",
        type=["pdf", "docx", "txt"],
    )

    if uploaded is not None:
        suffix = Path(uploaded.name).suffix.lower()
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(uploaded.getvalue());  tmp_path = tmp.name

        st.session_state.update(tmp_path=tmp_path, file_name=uploaded.name,
                                file_suffix=suffix, phase="review")

        with st.spinner("Extracting text and detecting PII…"):
            try:
                original_text = read_file(tmp_path)
                st.session_state.original_text = original_text
                engine = ContractRedactor(
                    confidence_threshold=confidence_threshold,
                    entities=selected_entities, use_bert=use_bert,
                )
                entities = engine.analyze_only(
                    original_text, manual_phrases=st.session_state.manual_phrases
                )
                st.session_state.detected_entities = entities
                st.session_state.approved_indices  = set(range(len(entities)))
            except Exception as exc:
                st.error(f"Could not process document: {exc}")
                st.session_state.phase = "upload";  st.stop()
        st.rerun()

# ─────────────────────────────────────────────────────────────────────────────
# Phase: Review
# ─────────────────────────────────────────────────────────────────────────────
elif st.session_state.phase == "review":
    suffix   = st.session_state.file_suffix
    tmp_path = st.session_state.tmp_path

    if st.button("↩ Upload a different document", key="up_rev"):
        _reset()

    n = len(st.session_state.detected_entities)
    st.markdown(
        f"**{st.session_state.file_name}** — "
        f"**{n}** proposed redaction{'s' if n != 1 else ''} detected."
    )

    doc_col, panel_col = st.columns([5, 2])

    with doc_col:
        if st.session_state.drawing_mode and suffix == ".pdf":
            st.markdown("**Drawing mode — drag to draw redaction boxes**")
            _render_doc_drawing(tmp_path)
        else:
            st.markdown("**Document preview — proposed redactions highlighted**")
            _render_doc_preview(suffix, tmp_path)
            if suffix != ".pdf" and st.session_state.original_text:
                _scroll_sync_js(len(st.session_state.original_text))

    with panel_col:
        _render_right_panel()

# ─────────────────────────────────────────────────────────────────────────────
# Phase: Done
# ─────────────────────────────────────────────────────────────────────────────
elif st.session_state.phase == "done":
    st.success("✅ Redactions applied successfully.")

    if st.button("↩ Upload a different document", key="up_done"):
        _reset()

    suffix         = st.session_state.file_suffix
    tmp_path       = st.session_state.tmp_path
    redacted_bytes = st.session_state.redacted_bytes

    doc_col, panel_col = st.columns([5, 2])

    with doc_col:
        if st.session_state.drawing_mode and suffix == ".pdf":
            st.markdown("**Drawing mode — drag to draw additional redaction boxes on the redacted document**")
            # Use the redacted PDF as background so the user sees black boxes already applied
            bg = st.session_state.get("redacted_tmp_path") or tmp_path
            _render_doc_drawing(bg, highlight_vals=[])
        else:
            st.markdown("**Redacted document**")
            _render_redacted_doc(suffix, redacted_bytes)

    with panel_col:
        # ── Drawing mode toggle (available in done phase too) ───────────────
        st.markdown('<div class="right-panel-header">✏️ Drawing Mode</div>',
                    unsafe_allow_html=True)
        drawing_mode = st.toggle(
            "Enable drawing mode",
            value=st.session_state.drawing_mode,
            key="draw_toggle_done",
            help="Draw additional black redaction boxes on the redacted PDF, then re-apply.",
        )
        if drawing_mode != st.session_state.drawing_mode:
            st.session_state.drawing_mode = drawing_mode
            st.rerun()
        if drawing_mode and suffix != ".pdf":
            st.info("Drawing mode is for PDF files only.")
        st.markdown("<hr style='margin:5px 0'>", unsafe_allow_html=True)

        # ── Download ────────────────────────────────────────────────────────
        st.markdown('<div class="right-panel-header">⬇️ Download</div>',
                    unsafe_allow_html=True)
        stem = Path(st.session_state.file_name).stem
        ext  = st.session_state.redacted_ext
        st.download_button(
            label=f"Download redacted document ({ext})",
            data=redacted_bytes,
            file_name=f"redacted_{stem}{ext}",
            mime=st.session_state.redacted_mime,
            use_container_width=True,
        )
        st.markdown("---")

        n_ap  = len(st.session_state.approved_indices)
        n_tot = len(st.session_state.detected_entities)
        drawn = sum(len(v) for v in st.session_state.drawn_rects.values())
        st.markdown(
            f"**{n_ap}** of **{n_tot}** text entities redacted"
            + (f" + **{drawn}** drawn box{'es' if drawn != 1 else ''}." if drawn else ".")
        )

        ap_ents = [st.session_state.detected_entities[i]
                   for i in st.session_state.approved_indices]
        if ap_ents:
            st.dataframe(
                pd.DataFrame([{"Type": e.entity_type,
                               "Redacted value": e.original_value,
                               "Conf": f"{e.score:.0%}"} for e in ap_ents]),
                use_container_width=True, hide_index=True,
            )

        st.markdown("---")
        c1, c2 = st.columns(2)
        if c1.button("🔄 Re-review", use_container_width=True):
            st.session_state.phase = "review"
            st.rerun()
        if drawing_mode and suffix == ".pdf":
            if c2.button("✅ Re-apply", use_container_width=True, type="primary"):
                _apply_redactions()
