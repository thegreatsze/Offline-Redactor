"""
Custom Presidio recognizers for contract-specific PII entities.

Adds recognizers for:
  - Contract IDs (CONTRACT-YYYY-NNNNN, CON-NNNNN)
  - EIN / Tax IDs (NN-NNNNNNN)
  - Bank routing numbers (9 digits)
  - Singapore NRIC / FIN numbers ([STFG]DDDDDDDL)
  - Street addresses (regex heuristics)
"""

from presidio_analyzer import PatternRecognizer, Pattern


def get_contract_id_recognizer() -> PatternRecognizer:
    """
    Create a recognizer for contract IDs.

    Matches patterns like:
        - CONTRACT-2024-00123
        - CON-00123
    """
    patterns = [
        Pattern(name="contract_id_long", regex=r"\bCONTRACT-\d{4}-\d{5}\b", score=0.9),
        Pattern(name="contract_id_short", regex=r"\bCON-\d{5}\b", score=0.85),
    ]
    return PatternRecognizer(
        supported_entity="CONTRACT_ID",
        patterns=patterns,
        name="ContractIdRecognizer",
    )


def get_ein_recognizer() -> PatternRecognizer:
    """
    Create a recognizer for EIN (Employer Identification Number) / Tax IDs.

    Matches the format: NN-NNNNNNN (e.g., 12-3456789).
    """
    patterns = [
        Pattern(name="ein", regex=r"\b\d{2}-\d{7}\b", score=0.85),
    ]
    return PatternRecognizer(
        supported_entity="EIN",
        patterns=patterns,
        name="EINRecognizer",
    )


def get_routing_number_recognizer() -> PatternRecognizer:
    """
    Create a recognizer for US bank routing numbers (9 consecutive digits).

    Context words raise confidence to reduce false positives on bare 9-digit strings.
    """
    patterns = [
        Pattern(name="routing_number", regex=r"\b\d{9}\b", score=0.6),
    ]
    return PatternRecognizer(
        supported_entity="BANK_ROUTING",
        patterns=patterns,
        context=["routing", "aba", "routing number", "bank routing"],
        name="BankRoutingRecognizer",
    )


def get_nric_recognizer() -> PatternRecognizer:
    """
    Create a recognizer for Singapore NRIC and FIN numbers.

    Format: one letter [S/T/F/G], 7 digits, one checksum letter.
    Examples: S9006302B, T1234567A, G8765432Z, F0123456X
    """
    patterns = [
        Pattern(name="nric_sg", regex=r"\b[STFG]\d{7}[A-Z]\b", score=0.92),
    ]
    return PatternRecognizer(
        supported_entity="NRIC_SG",
        patterns=patterns,
        context=["nric", "fin", "ic number", "identification", "passport", "id no"],
        name="NRICSGRecognizer",
    )


def get_address_recognizer() -> PatternRecognizer:
    """
    Create a heuristic regex recognizer for street addresses.

    Covers:
      - General street addresses (e.g., "4821 Birchwood Drive")
      - Singapore-style addresses with unit numbers and postal codes
        (e.g., "245 Orchard Boulevard #02-01, Singapore 248648")
    """
    street_suffixes = (
        r"(?:Avenue|Ave|Boulevard|Blvd|Road|Rd|Street|St|Drive|Dr|Lane|Ln|"
        r"Close|Crescent|Terrace|Park|Way|Place|Pl|Court|Ct|Highway|Hwy|"
        r"Parkway|Pkwy|Circuit|Grove|Rise|Walk|Link|View|Heights|Gardens)"
    )
    patterns = [
        # Singapore-style: "245 Orchard Boulevard #02-01, Singapore 248648"
        Pattern(
            name="address_sg",
            regex=(
                r"\b\d{1,5}\s+[\w\s]{2,40}"
                + street_suffixes
                + r"(?:\s+#\d{2,3}-\d{2,4})?"
                r"(?:,\s*(?:Singapore|S'pore)\s+\d{6})?"
            ),
            score=0.80,
        ),
        # General: "4821 Birchwood Drive, Columbus, Ohio 43201"
        Pattern(
            name="address_general",
            regex=(
                r"\b\d{1,5}\s+[\w]+(?:\s+[\w]+){0,4}\s+"
                + street_suffixes
                + r"(?:,\s*[\w\s]+(?:,\s*[A-Z]{2}\s+\d{5}(?:-\d{4})?)?)?"
            ),
            score=0.70,
        ),
    ]
    return PatternRecognizer(
        supported_entity="ADDRESS",
        patterns=patterns,
        context=["address", "located at", "residing at", "reside", "residence", "premises", "registered at"],
        name="AddressRecognizer",
    )


def register_custom_recognizers(analyzer_engine) -> None:
    """
    Register all custom recognizers with the given AnalyzerEngine.

    Args:
        analyzer_engine: A Presidio AnalyzerEngine instance.
    """
    recognizers = [
        get_contract_id_recognizer(),
        get_ein_recognizer(),
        get_routing_number_recognizer(),
        get_nric_recognizer(),
        get_address_recognizer(),
    ]
    for recognizer in recognizers:
        analyzer_engine.registry.add_recognizer(recognizer)
